package com.example.tgs;

public class Constant {
    public static final String API_KEY = "4361c93338981f2468758743afdad6b4";
    public static final String URL_IMAGE_BASE = "https://image.tmdb.org/t/p/w342";
    public static final String MOVIES_URL = "https://api.themoviedb.org/3/";
    public static final String DISCOVER = "discover/movie";
}
